package com.gof.util;

public class StreamUtil {
//	public static <T, K extends Comparable<K>> Collector<T, ?, TreeMap<K, List<T>>> sortedGroupingBy(Function<T, R> function){
//		return Collectors.groupingBy(function, TreeMap::new, Collectors.toList());
//	}
}
